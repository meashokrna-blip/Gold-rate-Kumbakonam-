package com.example.kumbakonamgoldrate

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class GoldWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = try {
        val snapshot = GoldRepository().fetch()
        val prefs = GoldPrefs(applicationContext)
        val old = prefs.load().lastOrNull()?.rate22 ?: snapshot.today.rate22
        prefs.save(snapshot)
        val sovereign = snapshot.today.rate22 * 8
        val reference = prefs.referenceSovereign()
        if (prefs.alertEnabled() && reference > 0 && sovereign <= reference - 500) {
            sendNotification(sovereign, reference)
            prefs.setReference(sovereign)
        } else if (reference <= 0) {
            prefs.setReference(sovereign)
        }
        Result.success()
    } catch (_: Exception) { Result.retry() }

    private fun sendNotification(current: Double, reference: Double) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel("gold", "Gold rate alerts", NotificationManager.IMPORTANCE_DEFAULT)
        manager.createNotificationChannel(channel)
        val n = NotificationCompat.Builder(applicationContext, "gold")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Kumbakonam gold rate alert")
            .setContentText("22K sovereign is now ₹${money(current)} — ₹500+ below your reference ₹${money(reference)}")
            .setAutoCancel(true)
            .build()
        manager.notify(2208, n)
    }

    private fun money(v: Double) = String.format("%,.0f", v)
}
