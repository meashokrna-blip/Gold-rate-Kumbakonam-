package com.example.kumbakonamgoldrate

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        scheduleWorker()
        setContent { GoldScreen() }
    }
    private fun scheduleWorker() {
        val req = PeriodicWorkRequestBuilder<GoldWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("gold-daily", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    @Composable fun GoldScreen() {
        val repo = remember { GoldRepository() }
        val prefs = remember { GoldPrefs(this) }
        var history by remember { mutableStateOf(prefs.load()) }
        var loading by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }
        var alert by remember { mutableStateOf(prefs.alertEnabled()) }
        val current = history.lastOrNull()
        val rate22 = current?.rate22 ?: 0.0
        val rate24 = current?.rate24 ?: 0.0
        val prediction = if (history.size >= 3) predict(history.takeLast(7).map { it.rate22 }) else rate22
        fun refresh() { lifecycleScope.launch { loading = true; error = null; try { val s=repo.fetch(); prefs.save(s); history=s.history } catch(e:Exception){ error=e.message ?: "Update failed" }; loading=false } }
        LaunchedEffect(Unit) { refresh() }
        MaterialTheme {
            Surface(Modifier.fillMaxSize()) {
                LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                    item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) { Column { Text("Kumbakonam Gold Rate", fontSize=24.sp); Text("Live local reference", color=MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton(onClick={refresh}) { Icon(Icons.Default.Refresh,"Refresh") } } }
                    item { Card(shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(20.dp)) { Text("22K", color=MaterialTheme.colorScheme.onSurfaceVariant); Text("₹${money(rate22)} / g", fontSize=34.sp); Text("1 sovereign (8g): ₹${money(rate22*8)}", fontSize=18.sp); Spacer(Modifier.height(6.dp)); Text("24K: ₹${money(rate24)} / g"); if(error!=null) Text(error!!, color=MaterialTheme.colorScheme.error) } } }
                    item { Card(shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text("Last 7 Days", fontSize=20.sp); Spacer(Modifier.height(10.dp)); GoldChart(history.takeLast(7).map{it.rate22}); Text("7-day change: ₹${money((history.lastOrNull()?.rate22 ?: 0.0)-(history.firstOrNull()?.rate22 ?: 0.0))}") } } }
                    item { Card(shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text("Next 2 Days — trend prediction", fontSize=20.sp); Text("Tomorrow: ₹${money(prediction)} / g", fontSize=18.sp); Text("Day after tomorrow: ₹${money(prediction + (prediction-rate22))}"); Text("Estimate only; market prices can change suddenly.", fontSize=12.sp, color=MaterialTheme.colorScheme.onSurfaceVariant) } } }
                    item { Card { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Notifications,null); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text("₹500 sovereign-drop alert");Text(if(alert)"ON — checks automatically" else "OFF")} Switch(alert,{v->alert=v;prefs.setAlert(v)}) } } }
                    item { if(loading) LinearProgressIndicator(Modifier.fillMaxWidth()) else Text("Source: India Today • Kumbakonam", fontSize=12.sp, color=MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
}

private fun predict(values: List<Double>): Double { val n=values.size; val xm=(n-1)/2.0; val ym=values.average(); var num=0.0; var den=0.0; for(i in values.indices){num+=(i-xm)*(values[i]-ym);den+=(i-xm)*(i-xm)}; val slope=if(den==0.0)0.0 else num/den; return (ym+slope*(n)).coerceAtLeast(0.0) }
private fun money(v:Double)=v.roundToInt().toString().reversed().chunked(3).joinToString(",").reversed()
@Composable private fun GoldChart(values:List<Double>){ Canvas(Modifier.fillMaxWidth().height(140.dp)){if(values.size<2)return@Canvas;val min=values.minOrNull()?:0.0;val max=values.maxOrNull()?:1.0;val r=(max-min).takeIf{it>0}?:1.0;val p=Path();values.forEachIndexed{i,v->{val x=i*size.width/(values.size-1);val y=size.height-((v-min)/r).toFloat()*size.height;if(i==0)p.moveTo(x,y)else p.lineTo(x,y)} };drawPath(p,MaterialTheme.colorScheme.primary,style=Stroke(5f))}}
