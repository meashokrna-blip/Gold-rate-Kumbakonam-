package com.example.kumbakonamgoldrate

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class GoldPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("gold", Context.MODE_PRIVATE)
    fun save(snapshot: GoldSnapshot) {
        val arr = JSONArray()
        snapshot.history.forEach { d ->
            arr.put(JSONObject().apply { put("date", d.date); put("r22", d.rate22); put("r24", d.rate24) })
        }
        prefs.edit().putString("history", arr.toString()).putLong("updated", snapshot.updatedAt).apply()
    }
    fun load(): List<GoldDay> {
        val raw = prefs.getString("history", null) ?: return emptyList()
        val arr = JSONArray(raw)
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            GoldDay(o.getString("date"), o.getDouble("r22"), o.getDouble("r24"))
        }
    }
    fun alertEnabled() = prefs.getBoolean("alert", true)
    fun setAlert(v: Boolean) = prefs.edit().putBoolean("alert", v).apply()
    fun referenceSovereign() = prefs.getFloat("reference", 0f).toDouble()
    fun setReference(v: Double) = prefs.edit().putFloat("reference", v.toFloat()).apply()
}
