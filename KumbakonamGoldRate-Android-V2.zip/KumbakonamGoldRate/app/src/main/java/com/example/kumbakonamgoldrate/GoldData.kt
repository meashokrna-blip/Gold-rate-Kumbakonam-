package com.example.kumbakonamgoldrate

data class GoldDay(val date: String, val rate22: Double, val rate24: Double)
data class GoldSnapshot(val today: GoldDay, val history: List<GoldDay>, val source: String, val updatedAt: Long)
