package com.example.kumbakonamgoldrate

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.text.SimpleDateFormat
import java.util.Locale

class GoldRepository {
    private val url = "https://www.indiatoday.in/commodity/gold-rate-in-kumbakonam-today"

    suspend fun fetch(): GoldSnapshot = withContext(Dispatchers.IO) {
        val doc = Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Android) KumbakonamGoldRate/2.0")
            .timeout(15000)
            .get()

        val text = doc.text()
        val current22 = findRate(text, "22 carat/10 grams")
        val current24 = findRate(text, "24 carat/10 grams")
        if (current22 == null || current24 == null) {
            throw IllegalStateException("Could not read the Kumbakonam gold rate from the source page")
        }

        val history = parseHistory(doc)
        val today = GoldDay(todayLabel(), current22 / 10.0, current24 / 10.0)
        val seven = (listOf(today) + history).distinctBy { it.date }.take(7).reversed()
        GoldSnapshot(today, seven, "India Today • Kumbakonam", System.currentTimeMillis())
    }

    private fun findRate(text: String, marker: String): Double? {
        val i = text.indexOf(marker, ignoreCase = true)
        if (i < 0) return null
        val tail = text.substring(i, minOf(i + 180, text.length))
        val m = Regex("₹\\s*([0-9,]+)").find(tail) ?: return null
        return m.groupValues[1].replace(",", "").toDoubleOrNull()
    }

    private fun parseHistory(doc: org.jsoup.nodes.Document): List<GoldDay> {
        val out = mutableListOf<GoldDay>()
        for (table in doc.select("table")) {
            for (row in table.select("tr")) {
                val cells = row.select("th,td").map { it.text().trim() }
                if (cells.size >= 3 && cells[0].contains("Sep", true)) {
                    val nums = cells.drop(1).mapNotNull { Regex("([0-9,]+)").find(it)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() }
                    if (nums.size >= 2) out += GoldDay(cells[0], nums[1] / 10.0, nums[0] / 10.0)
                }
            }
        }
        return out.distinctBy { it.date }
    }

    private fun todayLabel(): String = SimpleDateFormat("dd MMM", Locale.US).format(System.currentTimeMillis())
}
