# Kumbakonam Gold Rate — Android Version 2

Version 2 adds:
- Live rate refresh from the Kumbakonam gold-rate source page.
- Automatic 7-day history saved locally.
- Daily background refresh using Android WorkManager.
- Android notification permission and actual notification channel.
- ₹500 sovereign-drop alert logic.
- 22K and 24K display.
- 7-day chart.
- Simple 2-day trend prediction.

## Data source
The current prototype reads the Kumbakonam page published by India Today:
https://www.indiatoday.in/commodity/gold-rate-in-kumbakonam-today

The site currently publishes Kumbakonam 22K/24K prices and recent historical prices. Rates can differ between providers, so the app identifies the source.

## Important production note
The scraper is a prototype integration. A stable licensed/API feed is preferable for a production app because a website can change its HTML structure or access rules. Replace `GoldRepository` with an API implementation when a commercial/live data provider is selected.

## Android notifications
Android 13+ requires notification permission. The app asks for it at startup. The daily worker requires network connectivity and stores the latest seven observations.

## Build
Open the project in Android Studio, sync Gradle, and build the debug APK.
